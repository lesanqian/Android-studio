package sau.zhaole.file_manager;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class MyService extends Service {
    MediaPlayer mediaPlayer;     //必须要实现此方法，IBinder对象用于交换数据，此处暂时不实现
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onCreate() {
        super.onCreate();
        mediaPlayer =MediaPlayer.create(this, Uri.parse("storage/emulated/0/Download/movie.mp4"));//文件路径
        Log.e("TAG","create");

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        play();
        Log.e("TAG","start");
        return super.onStartCommand(intent, flags, startId);
    }
    private void play() {
        mediaPlayer.start();
    }
    @Override

    public void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        Log.e("TAG","destoryed");
    }
}
