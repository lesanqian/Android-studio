package sau.zhaole.file_manager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.VideoView;

public class Main2Activity extends AppCompatActivity {

    String mp4文件路径;
    VideoView 播放窗口;
    private Button 后台播放;
    private boolean status=false; //后台播放
    private static final int FILE_SELECT_CODE=1;
    private static final String TAG="VideoActivity";
    Button 播放, 暂停, 重播, 浏览;
    private SeekBar 进度条播放;
    Handler handler=new Handler();//异步处理
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        播放窗口 =findViewById(R.id.video_view);
        播放 =findViewById(R.id.play);
        暂停 =findViewById(R.id.pause);
        重播 =findViewById(R.id.replay);
        浏览 =findViewById(R.id.choice);
        进度条播放 =findViewById(R.id.sb_1);
        进度条播放.setEnabled(false);//进度条不可拖动
        进度条播放.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                //当拖动条发生变化时调用该方法
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //        当开始滑动滑块时调用该方法（即按下鼠调用一次）
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //        当结束对滑块滑动时,调用该方法（即松开鼠标）
                int pos=seekBar.getProgress()* 播放窗口.getDuration()/100;
                播放窗口.seekTo(pos);
            }
        });
        浏览.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//在文件夹中打开
                Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");//设置类型，这是任意类型
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                 mp4文件路径 =intent.getStringExtra("currentFile");
                startActivityForResult(intent,1);
            }
        });
        播放.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!播放窗口.isPlaying()){//播放
                    播放窗口.start();
                    进度条播放.setEnabled(true);
                    handler.post(runnable);
                }
            }
        });
        暂停.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(播放窗口.isPlaying()){//暂停
                    播放窗口.pause();
                }
            }
        });
        重播.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(播放窗口.isPlaying()){
                    播放窗口.resume();//重新播放
                }
            }
        });//给按钮加监听
        if(ContextCompat.checkSelfPermission(Main2Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(Main2Activity.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
            //判断你是否授权，读取外储的权限
        }
        else {
            inintVideoPath();
        }
        后台播放 = (Button) findViewById(R.id.btn_open);//后台播放，不显示播放界面只播放音频，退出后继续播放，
        后台播放.setText("后台播放");
        后台播放.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, MyService.class);
                if (!status) {
                    后台播放.setText("停止播放");
                    startService(intent);//调用onCreate的方法
                    status = true;
                } else {
                    后台播放.setText("后台播放");
                    stopService(intent);//调用onDestory方法
                    status = false;
                }
            }
        });
    }
    private void inintVideoPath(){//播放路径
        Intent intent=getIntent();
        mp4文件路径 =intent.getStringExtra(MainActivity.MESSAGE);
        播放窗口.setVideoPath(mp4文件路径);//指定视频文件的路径
    }
//    public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
//        switch (requestCode){
//            case 1:
//                if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
//                    inintVideoPath();
//                }
//                else {
//                    Toast.makeText(this,"拒绝权限将无法访问程序",Toast.LENGTH_SHORT).show();
//                    finish();
//                }
//                break;
//            default:
//        }
//    }
    public void onDestroy(){//释放资源
        super.onDestroy();
        if(播放窗口 !=null){
            播放窗口.suspend();
        }
    }
//    public void onActivityResult(int requestCode, int resultCode, Intent data){
//        if(resultCode== Activity.RESULT_OK){
//            Uri uri=data.getData();
//            播放窗口.setVideoURI(uri);//将选择的文件路径给播放器
//            super.onActivityResult(requestCode, resultCode, data);
//            return;
//        }
//        if (requestCode == FILE_SELECT_CODE) {
//            Uri uri = data.getData();
//            Log.i(TAG, "------->" + uri.getPath());
//        }
//        super.onActivityResult(requestCode, resultCode, data);
//    }
    private Runnable runnable=new Runnable() {
        @Override
        public void run() { //进度条播放
            int progress=100* 播放窗口.getCurrentPosition()/ 播放窗口.getDuration();
            进度条播放.setProgress(progress);
            handler.postDelayed(this,100);
        }
    };
}
