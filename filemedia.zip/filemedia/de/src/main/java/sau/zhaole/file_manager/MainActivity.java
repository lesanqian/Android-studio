package sau.zhaole.file_manager;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class MainActivity extends AppCompatActivity {
    public static String MESSAGE;
    ListView listView显示文件;
    TextView textView显示当前文件路径;
    File 上一级文件路径;
    File[] 当前文件路径;
    EditText 输入框;
    View view;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        PermissionUtils.授予文件访问权限(this, 1);

        listView显示文件 = findViewById(R.id.list);
        textView显示当前文件路径 = findViewById(R.id.path);
        registerForContextMenu(listView显示文件);//上下文菜单 长按弹出上下文菜单，显示重命名，删除，打开
        boolean sdCardExist = Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED);   //判断sd卡是否存在
        final File sd_care;
        sd_care = Environment.getRootDirectory();//sd卡根目录
        if (sdCardExist) {//显示当前路径下的文件
            上一级文件路径 = sd_care;
            当前文件路径 = 上一级文件路径.listFiles();
            //使用当前目录下的全部文件，文件夹来填充listView
            inflateListView(当前文件路径);
        }
        listView显示文件.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> but返回, View view, int position,
                                    long id) {
                // TODO Auto-generated method stub
                //如果用户单击了文件，直接返回，不做任何处理
                if (当前文件路径[position].isFile()) {//判断是否是文件
                    String filename = 当前文件路径[position].getName();// 文件名
                    String end = filename.substring(filename.lastIndexOf(".") + 1, filename.length()).toLowerCase();
                    MESSAGE= 当前文件路径[position].getPath();
                    if(end.equals("mp4"))//判断是否为MP4 ，是则跳转第二级activity，实现播放，其他文件不做处理
                    {
                        Intent intent;
                        intent = new Intent(MainActivity.this,Main2Activity.class);
                        intent.putExtra(MESSAGE, 当前文件路径[position].getPath());
                        startActivity(intent);
                    }
                }else {//点击的是文件夹显示该文件夹下所有文件
                    //获取用户点击的文件夹下的所有文件
                    File[] tmp = 当前文件路径[position].listFiles();
                    //获取用户单击的列表项对应的文件夹，设为当前父文件夹
                    上一级文件路径 = 当前文件路径[position];
                    //保存当前父文件夹下的全部文件和文件夹
                    当前文件路径 = tmp;
                    //再次更新listView
                    inflateListView(当前文件路径);
                }
            }
        });

        // 长按item的事件响应
        listView显示文件.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                fileHandle(当前文件路径[position]);
                return false;
            }
        });
    }
    //填充listView
    private void inflateListView(File[] files) {
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        int i = 0;
        for (i = 0; i < files.length; i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            // 如果当前File是文件夹，使用folder图标、否则是file图标
            String filename = files[i].getName();// 文件名
            String end = filename.substring(filename.lastIndexOf(".") + 1, filename.length()).toLowerCase();
            if (files[i].isDirectory()) {//显示图片文件名
                map.put("icon", R.drawable.folder);
 //               map.put("文件or目录", 0);
            } else {
                if(end.equals("txt"))
                    map.put("icon",R.drawable.timg);
                else
                    map.put("icon", R.drawable.file);
 //                   map.put("文件or目录", 1);
            }
            map.put("fileName", files[i].getName());
            list.add(map);

        }
        //创建一个simpleadaptor, 使用ID为R.id.icon的组将来显示icon对应的值
        SimpleAdapter simpleAdapter = new SimpleAdapter(this, list, R.layout.line, new String[]{"icon", "fileName"}, new int[]{R.id.icon, R.id.file_name});
        //为listView设置Adapter
        listView显示文件.setAdapter(simpleAdapter);
        try {
            textView显示当前文件路径.setText("当前路径为: " + 上一级文件路径.getCanonicalPath());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 点击返回键, 返回上一级菜单
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        try {
            if (!上一级文件路径.getCanonicalPath().equals("/mnt/sdcard")) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    //获取上一级目录
                    上一级文件路径 = 上一级文件路径.getParentFile();
                    //列出当前目录下所有文件
                    当前文件路径 = 上一级文件路径.listFiles();
                    //再次更新ListView
                    inflateListView(当前文件路径);
                }
                else {
                    Toast.makeText(this, "退出APP", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    // 创建选项菜单
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 0, 1, "System目录");
        menu.add(0, 1, 2, "新建文件");
        menu.add(0, 2, 3, "SD卡目录");
        // Data目录, 在模拟器可能涉及到权限, 在手机上可能好用
        // menu.getItem(1).setVisible(false);
        return super.onCreateOptionsMenu(menu);
    }

    // 选项菜单监听器 ，实现目录切换，新建文件夹
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Log.i("输出", item.getTitle().toString());
        String 文件路径 = "";
        switch (item.getItemId()) {
            case 0:
                上一级文件路径 = Environment.getRootDirectory();
                break;
            case 1:
                Log.i("输出", Environment.getDataDirectory().toString());
                final File file_2 = new File(上一级文件路径.getAbsolutePath(), "新建文件夹");
                file_2.mkdirs();
                break;
            case 2:
                Log.i("输出", getExternalFilesDir(null).toString());
                上一级文件路径 = Environment.getExternalStorageDirectory();
                break;
        }
        当前文件路径 = 上一级文件路径.listFiles();
        //使用当前目录下的全部文件，文件夹来填充listView
        inflateListView(当前文件路径);
        return true;
    }



    private void fileHandle(final File file) {//文件句柄
        DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if(which==0)  {//重命名 ，
                    LayoutInflater factory = LayoutInflater.from(MainActivity.this);
                    view = factory.inflate(R.layout.dialog, null);
                    输入框 =  view.findViewById(R.id.editText);
                    输入框.setText(file.getName());
                    DialogInterface.OnClickListener listener2 = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String modifyName = 输入框.getText().toString();
                            final String fpath = file.getParentFile().getPath();
                            final File newFile = new File(fpath + "/" + modifyName);
                            if (newFile.exists()) {
                                if (!modifyName.equals(file.getName())) {
                                    new AlertDialog.Builder(MainActivity.this)
                                            .setTitle("注意!")
                                            .setMessage("文件名已存在，是否覆盖？")
                                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int
                                                        which) {
                                                    if (file.renameTo(newFile)){
                                                        inflateListView(上一级文件路径.listFiles());
                                                        displayToast("重命名成功！");
                                                    } else{
                                                        displayToast("重命名失败！");
                                                    }
                                                }
                                            }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int
                                                which) { }}).show();
                                }
                            } else {
                                if (file.renameTo(newFile)){
                                    inflateListView(上一级文件路径.listFiles());
                                    displayToast("重命名成功！");
                                }
                                else{
                                    displayToast("重命名失败！");
                                }
                            }
                        }
                    };
                    AlertDialog renameDialog = new AlertDialog.Builder(MainActivity.this).create();
                    renameDialog.setView(view);
                    renameDialog.setButton("确定", listener2);
                    renameDialog.setButton2("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int
                                which) {
                            // TODO Auto-generated method stub
                        }
                    });
                    renameDialog.show();
                }
                //删除文件
                else if(which==1) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("注意!")
                            .setMessage("确定要删除此文件吗？")
                            .setPositiveButton("确定", new
                                    DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int
                                                which) {
                                            if (file.delete()) {
                                                inflateListView(上一级文件路径.listFiles());
                                                displayToast("删除成功！");
                                            } else {
                                                displayToast("删除失败！");
                                            }
                                        }

                                    }).setNegativeButton("取消", new
                            DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int
                                        which) { }
                            }).show();
                }
                else {
                    // 打开文件
//                    new AlertDialog.Builder(MainActivity.this)
//                            .setTitle("注意!")
//                            .setMessage("确定要打开该文件夹吗？")
//                            .setPositiveButton("确定", new
//                                    DialogInterface.OnClickListener() {
//                                        @Override
//                                        public void onClick(DialogInterface dialog, int
//                                                which) {
//                                            inflateListView(上一级文件路径.listFiles());
//                                        }
//                                    }).setNegativeButton("取消", new
//                            DialogInterface.OnClickListener() {
//                                @Override
//                                public void onClick(DialogInterface dialog, int
//                                        which) { }
//                            }).show();
                }
            }
        };
        //选择文件时，弹出增删该操作选项对话框
        String[] menu = {"重命名","删除文件"};
        new AlertDialog.Builder(MainActivity.this)
                .setTitle("请选择要进行的操作!")
                .setItems(menu, listener)
                .setPositiveButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void  onClick(DialogInterface dialog, int
                            which) { }
                }).show();
    }
    private void  displayToast(String message){
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}
